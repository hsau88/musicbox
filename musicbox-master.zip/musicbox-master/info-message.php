<?php
    // welcomeMsg.php
    //  Gets the form data and prints it to screen
    
    // handle get request
    // $strSoFar = $_GET["StringSoFar"];
    // print "Welcome  <font color='green'> $strSoFar </font>";
    
    // handle post request
    $strSoFar = $_POST["StringSoFar"];
    print "Welcome  <font color='green'> $strSoFar </font>";
    
    ?>
